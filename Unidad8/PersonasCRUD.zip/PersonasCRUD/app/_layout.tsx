import { Drawer } from 'expo-router/drawer';

export default function RootLayout() {
  return (
    <Drawer
      screenOptions={{
        headerStyle: { backgroundColor: '#007AFF' },
        headerTintColor: '#fff',
        drawerActiveTintColor: '#007AFF',
        drawerLabelStyle: { fontWeight: 'bold' },
      }}
    >
      <Drawer.Screen
        name="index"
        options={{ title: 'Inicio' }}
      />
      <Drawer.Screen
        name="UI/view/persona/index"
        options={{ title: 'Personas' }}
      />
      <Drawer.Screen
        name="UI/view/departamento/index"
        options={{ title: 'Departamentos' }}
      />
    </Drawer>
  );
}
