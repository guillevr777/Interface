import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Text, TouchableOpacity, View } from 'react-native';
import { CRUDPersonaVM } from '../../viewmodel/PersonasVM';

export default function ListadoPersonas() {
  const router = useRouter();
  const [vm] = useState(() => new CRUDPersonaVM());
  const [, forceUpdate] = useState(0);
  const refresh = () => forceUpdate(v => v + 1);

  useEffect(() => { vm.listar().then(refresh); }, []);

  if (vm.loading) return <ActivityIndicator size="large" color="#007AFF" />;

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <TouchableOpacity
        onPress={() => router.push('/UI/view/personas/EditarInsertarPersonas')}
      >
        <Text>+ Nueva Persona</Text>
      </TouchableOpacity>

      <FlatList
        data={vm.personas}
        keyExtractor={item => item.ID!.toString()}
        renderItem={({ item }) => (
          <View style={{ padding: 10, marginVertical: 5, backgroundColor: '#eee', borderRadius: 8 }}>
            <Text>{item.Nombre} {item.Apellidos}</Text>
            <TouchableOpacity onPress={() => router.push({
              pathname: '/UI/view/personas/EditarInsertarPersonas',
              params: { id: item.ID }
            })}>
              <Text>Editar</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}
