export class clsMensajeUsuario {
  Nombre: string;
  Mensaje: string; 
  
  constructor(nombre: string, mensaje: string) {
    this.Nombre = nombre;
    this.Mensaje = mensaje;
  }
}
